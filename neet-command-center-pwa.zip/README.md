# NEET Command Center — Mobile PWA

This is the phone-friendly installable version.

## Phone-only use
1. Put these files on a web host that gives HTTPS.
2. Open the HTTPS address in Chrome on Android.
3. Chrome menu → Add to Home screen / Install app.
4. The app opens in standalone mode like an app.

Important: a local `file://` HTML file cannot provide the full PWA install/notification experience. The site needs HTTPS.

The app contains the existing NEET tracker plus monthly calendar, daily planner, reminder permission flow, streak tracking and offline app-shell caching.
